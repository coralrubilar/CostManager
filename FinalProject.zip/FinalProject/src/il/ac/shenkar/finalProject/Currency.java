package il.ac.shenkar.finalProject;

public enum Currency {
    ILS, USD, EURO, GBP
}
