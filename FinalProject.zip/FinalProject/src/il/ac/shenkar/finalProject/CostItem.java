package il.ac.shenkar.finalProject;


import java.util.concurrent.atomic.AtomicInteger;

public class CostItem {

    private int id;
    private String description;
    private double sum;
    private Currency currency;
    private static AtomicInteger idCounter = new AtomicInteger();
    private Category category;

    public CostItem(String description, double sum,Currency currency, Category category) {
//        this.description = description;
//        this.sum = sum;
//        this.currency = currency;

        setDescription(description);
        setCurrency(currency);
        setSum(sum);
        id = idCounter.getAndIncrement();
        if(category.getCategory() !="") {
            this.category = category;
        }
    }

    @Override
    public String toString() {
        return "CostItem{" +
                "description='" + description + '\'' +
                ", sum=" + sum +
                ", currency=" + currency +
                ", id=" + id +
                ", category="+category.getCategory()+" };";
    }

    public int getId(){
        return this.id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getSum() {
        return sum;
    }

    public void setSum(double sum) {
        this.sum = sum;
    }

    public Currency getCurrency() {
       return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Category getCategory(){
        return this.category;
    }


}

