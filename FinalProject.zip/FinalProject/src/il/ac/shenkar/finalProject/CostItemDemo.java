package il.ac.shenkar.finalProject;

public class CostItemDemo {
    public static void main(String args[])  {

        CategoryList categoryList = new CategoryList();
        categoryList.addCategory("hi");
        //categoryList.addCategory("hi");
        //categoryList.addCategory("hi2");
        Category c = null;
        try {
            c = new Category("hi");
        } catch (CostManagerException e) {
            e.printStackTrace();
        }
        // Category d = new Category("hi2");
        CostItem item = new CostItem("nice carpet",990,Currency.USD,c);
        CostItem item2 = new CostItem("nice carpet",990,Currency.USD,c);
        CostItem item3 = new CostItem("nice carpet",990,Currency.USD,c);
        CostItem item4 = new CostItem("nice carpet",990,Currency.USD,c);
        System.out.println(item);
        System.out.println(item2);
        System.out.println(item3);
        System.out.println(item4);
        DerbyDBModel ddb = new DerbyDBModel();
        try {
            ddb.addCostItem(item);
            ddb.deleteCostItem(item);
            ddb.deleteCostItem(item);

        } catch (CostManagerException e) {
            e.printStackTrace();
        }


    }
}
