package il.ac.shenkar.finalProject;

import java.util.ArrayList;
import java.util.Arrays;

public class Category {
     private String category;
     CategoryList categoryList = new CategoryList();

    public Category(String category) throws CostManagerException {

             if(categoryList.Contain(category)){
                 this.category= category;
                 System.out.println("category exist");
             }else{
                 //System.out.println("category NOT exist");
                 throw new CostManagerException("category NOT exist");
             }
     }


     public String getCategory(){
        return this.category;
     }



}
