package il.ac.shenkar.finalProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DerbyDBModel implements IModel {
    @Override
    public void addCostItem(CostItem item) throws CostManagerException {
        String jdbcURL= "jdbc:derby:costManager;create=true";
        try {
            Connection connection = DriverManager.getConnection(jdbcURL);
            String sql = "Insert into costItem (id,description,sumPrice,currency,category) values ("+item.getId()+",'"+item.getDescription()+"',"+item.getSum()+
                    ",'"+item.getCurrency().toString()+"','"+item.getCategory().getCategory()+"')";
            Statement statement = connection.createStatement();
            int rows = statement.executeUpdate(sql);
            if(rows>0) {
                System.out.println("row in  prodact created");
            }else{
                System.out.println("row in  prodact NOT created");
            }
//            String shotdownURL = "jdbc:derby:;shutdown=true";
//            DriverManager.getConnection(shotdownURL);
        } catch (SQLException throwables) {
            //if(throwables.getSQLState().equals("XJ015")){
            //    System.out.println("Derby DB shutdown normally");
            //}else {
            throwables.printStackTrace();
            //}
        }

    }

    @Override
    public CostItem[] getCostItems() throws CostManagerException {

        return new CostItem[0];
    }

    @Override
    public void deleteCostItem(CostItem item) throws CostManagerException {
        String jdbcURL= "jdbc:derby:costManager;create=true";
        try {
            Connection connection = DriverManager.getConnection(jdbcURL);
            String sql ="DELETE FROM costItem WHERE id = "+item.getId();
            Statement statement = connection.createStatement();
            int rows = statement.executeUpdate(sql);
            if(rows>0) {
                System.out.println("row in  prodact removed");
            }else{
                System.out.println("row in  prodact NOT removed");
            }
//            String shotdownURL = "jdbc:derby:;shutdown=true";
//            DriverManager.getConnection(shotdownURL);
        } catch (SQLException throwables) {
            //if(throwables.getSQLState().equals("XJ015")){
            //    System.out.println("Derby DB shutdown normally");
            //}else {
            throwables.printStackTrace();
            //}
        }
    }


    public DerbyDBModel(){
        String jdbcURL= "jdbc:derby:costManager;create=true";
        try {
        Connection connection = DriverManager.getConnection(jdbcURL);
        String ceateTable = "CREATE TABLE costItem (id int not null,description varchar(255)," +
                "sumPrice double," +
                "currency varchar(255) not null," +
                "category varchar(255) not null)";
            Statement statement = connection.createStatement();
            statement.executeUpdate(ceateTable);
        } catch (SQLException throwables) {
            if(throwables.getSQLState().equals("X0Y32")) {
                System.out.println("Table costItem already exists!");
            }else{
            throwables.printStackTrace();
            }
        }

    }
    //...
}
